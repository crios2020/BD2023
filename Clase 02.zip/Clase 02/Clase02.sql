/*
	Bloque de comentarios
*/

-- Comentarios de una sola linea

#linéa de comentario no ANSI SQL

show databases;		-- muestra las BDs del server

-- ; es el terminador de sentencias
-- ctrol - enter : atajo para ejecutar solo una sentencia

SHOW DATABASES;		-- lenguaje no case sensitive

drop database if exists clase02;	-- borra la BD clase01
create database clase02;			-- crea la BD clase01
-- CREATE DATABASE CLASE01;

use clase02;						-- activa la BD clase01
show tables;						-- muestra el catalogo de tablas del server

/*
		Columnas - Campos
        Filas - Registros
        
        Metadato: en una tabla es la descripción de campos y tipo de datos de los campos.
        
        Planilla de Calculo trabaja datos en RAM
        Base de datos Trabaja todos los datos en Disco Duro
	
		MEMORIA RAM		Volatil			Caro $$$		Veloz		
        DISCO DURO		Persistente		Economico		Lento

*/


drop table if exists clientes;	-- borra la tabla clientes

-- creamos la tabla clientes
create table clientes(
	id int auto_increment primary key,
    nombre varchar(20)  not null,
    apellido varchar(20) not null,
    cuit char(13),
    direccion varchar(50),
    comentarios varchar(255)
);

show tables;
describe clientes;		-- muestra el metadato de la tabla
select * from clientes;	-- muestra los registros de la tabla

-- inserción de registros
insert into clientes (nombre,apellido,cuit,direccion) values
	('Juan','Perez','1233456','Lavalle 648');
insert into clientes (nombre,apellido,cuit,direccion) values
	('Maria','Gomez','6232323','Larrea 668');
    
  
-- 1- Borrar si existe la base de datos Agenda.

-- 2- Crear la base de datos Agenda.

-- 3- Ingresar a la base de datos creada (use).

-- 4- Crear una tabla llamada "agenda". Debe tener los siguientes campos:

--    nombre (cadena de 20), 
--    domicilio (cadena de 30)
--    telefono (cadena de 11)

-- 5- Visualizar las tablas existentes en la base de datos para verificar la creación de "agenda".

-- 6- Visualizar la estructura de campos de la tabla "agenda". (describe).

-- 7- Ingresar 10 registros con valores aleatorios.

-- 8- Seleccione y muestre todos los registros de la tabla:

-- Felicitaciones usted ha armado su agenda personal!!!!  